import asyncio
import json
import os
import random
import sqlite3
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton

BASE_DIR = Path(__file__).parent
DB_PATH = os.getenv("DB_PATH", str(BASE_DIR / "progress.db"))
TOKEN = os.getenv("BOT_TOKEN")

with open(BASE_DIR / "data" / "vocabulary.json", encoding="utf-8") as f:
    WORDS = json.load(f)

with open(BASE_DIR / "data" / "grammar.json", encoding="utf-8") as f:
    GRAMMAR = json.load(f)

dp = Dispatcher()

def init_db():
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS progress (
            user_id INTEGER NOT NULL,
            word_id INTEGER NOT NULL,
            correct INTEGER NOT NULL DEFAULT 0,
            wrong INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (user_id, word_id)
        )""")

def menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📚 Учить слова"), KeyboardButton(text="🔁 Повторение")],
            [KeyboardButton(text="🧩 Формы слов"), KeyboardButton(text="📖 Грамматика")],
            [KeyboardButton(text="🗣 Диалоги"), KeyboardButton(text="🎓 Экзамен A2")],
            [KeyboardButton(text="📊 Мой прогресс"), KeyboardButton(text="ℹ️ Помощь")]
        ],
        resize_keyboard=True
    )

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "Γεια σου! Добро пожаловать в Μαθαίνω Ελληνικά A2 🇬🇷\n\n"
        "Здесь будем готовиться к экзамену A2: учить слова, формы, грамматику и практиковать греческий.\n"
        "Выбери раздел в меню.",
        reply_markup=menu()
    )

@dp.message(F.text == "📚 Учить слова")
async def learn_words(message: Message):
    sample = WORDS[:5]
    lines = ["📚 Первые слова для изучения:\n"]
    for w in sample:
        lines.append(f"{w['greek']} — {w['ru']}\n{w.get('transcription','')}\nПример: {w.get('example','')}")
    await message.answer("\n\n".join(lines), reply_markup=menu())

@dp.message(F.text == "🔁 Повторение")
async def review(message: Message):
    w = random.choice(WORDS)
    await message.answer(
        f"Как переводится?\n\n**{w['greek']}**",
        parse_mode="Markdown",
        reply_markup=menu()
    )
    await message.answer(f"Ответ: {w['ru']}\nПример: {w.get('example','')}")

@dp.message(F.text == "🧩 Формы слов")
async def forms(message: Message):
    verbs = [w for w in WORDS if w.get("forms")]
    if not verbs:
        await message.answer("Формы для этого набора пока не добавлены.")
        return
    w = random.choice(verbs)
    await message.answer(f"{w['greek']} — {w['ru']}\nФормы: {w['forms']}")

@dp.message(F.text == "📖 Грамматика")
async def grammar(message: Message):
    item = random.choice(GRAMMAR)
    await message.answer(f"📖 {item['title']}\n\n{item['explanation']}\n\nПримеры:\n" + "\n".join(item["examples"]))

@dp.message(F.text == "🗣 Диалоги")
async def dialogues(message: Message):
    await message.answer(
        "🗣 Практика диалога A2\n\n"
        "Ситуация: ты в кафе.\n"
        "Официант: Τι θα θέλατε;\n"
        "Ты: Θα ήθελα έναν καφέ και ένα νερό.\n\n"
        "Перевод: Что бы вы хотели? — Я бы хотела кофе и воду."
    )

@dp.message(F.text == "🎓 Экзамен A2")
async def exam(message: Message):
    await message.answer(
        "🎓 Подготовка к экзамену A2\n\n"
        "В этом прототипе доступны короткие тренировочные задания. "
        "Полноценные пробные варианты чтения, аудирования, письма и устной речи "
        "будут добавлены в следующих версиях."
    )

@dp.message(F.text == "📊 Мой прогресс")
async def progress(message: Message):
    with sqlite3.connect(DB_PATH) as con:
        row = con.execute(
            "SELECT COALESCE(SUM(correct),0), COALESCE(SUM(wrong),0) FROM progress WHERE user_id=?",
            (message.from_user.id,)
        ).fetchone()
    await message.answer(f"📊 Твой прогресс\nПравильных ответов: {row[0]}\nОшибок: {row[1]}")

@dp.message(F.text == "ℹ️ Помощь")
async def help_message(message: Message):
    await message.answer(
        "Занимайся 15–20 минут в день. Начни со слов, затем повторяй формы и грамматику. "
        "Это ранняя версия бота: часть функций пока демонстрационная."
    )

async def main():
    if not TOKEN:
        raise RuntimeError("Не задан BOT_TOKEN. Добавь токен в Environment Variables на Render.")
    init_db()
    bot = Bot(TOKEN)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())